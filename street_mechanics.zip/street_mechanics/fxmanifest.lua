-- Generated automaticly by RB Generator.
fx_version('cerulean')
games({ 'gta5' })

shared_script('config.lua');


client_scripts({
    'client.lua',
    'config.lua'
});