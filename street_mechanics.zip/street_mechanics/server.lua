
local QBCore = nil 
local ESX = nil
Citizen.CreateThread(function()
    if Config.ESX then 
        TriggerEvent(Config.ESXT,function(obj)ESX = obj end)
    else
        local QBCore = exports['qb-core']:GetCoreObject()
    end
end)



RegisterNetEvent('a_cargoheist:payout')
AddEventHandler('a_cargoheist:payout', function(Typeofchoice)
    local Payout
        if Typeofchoice == 'normal' then 
            Payout = Config.Heist.Payout
        elseif Typeofchoice == 'hard' then 
            Payout = Config.Heist.PayoutHard
        end
        if Config.ESX then 
            local xPlayer = ESX.GetPlayerFromId(source)
            if Config.Heist.Blackmoney then 
                xPlayer.addAccountMoney('black_money', Payout)
            else
                xPlayer.addMoney(Payout)
            end
        else
            local src = source
            local Player  = QBCore.Functions.GetPlayer(src)
            Player.Functions.AddMoney('cash', Payout)
        end
end)